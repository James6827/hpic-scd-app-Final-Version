// adding .jsx file for error handlign when user clicks on it but we dont have anything written yet
import React from "react";

export default function Symptoms() {
  return (
    <div className="symptoms-container">
      <h1>Symptoms Page</h1>
      <p>Welcome to the HPIC symptoms resources section.</p>
    </div>
  );
}
