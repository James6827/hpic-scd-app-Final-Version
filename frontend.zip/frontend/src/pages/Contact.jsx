// adding .jsx file for error handlign when user clicks on it but we dont have anything written yet
import React from "react";

export default function Contact() {
  return (
    <div className="contact-container">
      <h1>Contact Page</h1>
      <p>Welcome to the HPIC contact page.</p>
    </div>
  );
}
